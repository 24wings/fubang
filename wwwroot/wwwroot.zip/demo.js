console.log('');

for (const element of elements) {

}